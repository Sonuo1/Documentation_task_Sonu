<center> <u> <h1 style="font-size: 50px;">BDD and test cases using Cucumber framework</h1> </u> </center>

## **Task requirement**

Behavioral-Driven Development (BDD) for a search feature to just illustrate the understanding for the same.

## **Environment details**

* OS: Ubuntu 23.04 (64-bit)
* Base

## **List of tools and technologies**

* IntelliJ IDEA (Community Edition) installed (2023.1.2 used in this document)
* Java installed (17.0.7 used in this document)
* Maven installed (3.6.3 used in this document)

## **Definition of tools**

* IntelliJ IDEA is undoubtedly the top-choice IDE for software developers. It makes Java and Kotlin development a more productive and enjoyable experience.

* Java is a programming language and a platform. Java is a high level, robust, object-oriented and secure programming language.

* Maven is a build automation tool used primarily for Java projects. Maven can also be used to build and manage projects written in C#, Ruby, Scala, and other languages.

## **Command for the installation or configuration**

* Installation of IntelliJ IDEA 2023.1.2 (Community Edition) (process for debian, Ubuntu and linux Mint)

## **System requirements: (from official site)**

![Alt text](c1.png)

First **download** the IntelliJ community edition (An open source IDE) from the official website.

Below are the instructions for installing from the official site:

![Alt text](c2.png)

* -x: It tells tar to extract an archive.
* -z: use gz compression
* -f: Read and write files from/to disk.

## **1. Adding cucumber plugin to IDE(Integrated Development Environment)**

Now we will add a cucumber plugin in it. To do so press **ctrl+alt+s**, it will open a settings dialog box where you have to select the plugin option from the left menu and search for **cucumber** plugin and install it, and then click apply and done.

![Alt text](c3.png)

## **2. Java 17 installation**

To install the Java 17 version use the below command -

~~~
sudo apt-get install openjdk-17-jdk
~~~

**Command description:**

* **sudo:** sudo command is used to execute the following commands with administrative or superuser privileges.

* **apt-get:** It is a package management command on Debian-based systems (like Ubuntu) used to interact with the Advanced Package Tool (APT) system to install, update, or remove software packages.

* **install:** It specifies that you want to install a package as per your requirements.

* **openjdk-17-jdk:** It is the name of the package you want to install. It specifies the OpenJDK 17 Java Development Kit, which is used for Java software development.

**Summary of the command:** This command installs JDK 17 on Debian-based Linux with the apt-get package manager, using sudo for admin rights.

![Alt text](c4.png)

![Alt text](c5.png)

## **3. Installation of Maven**
**To install Maven use command** 

~~~
sudo apt install maven
~~~
**Command description:**
* sudo: sudo command is used to execute the following commands with administrative or superuser privileges.


* apt: It is the package management tool for Debian-based Linux distributions. It is used to handle package installation, updates, and removal
* install: It specifies that you want to install a package as per your requirements.
* maven: It is the name of the package you want to install.

**Summary of the command:** The command **sudo apt install maven** is used to install Apache Maven, a build automation and project management tool, on a Debian-based Linux system like Ubuntu.

![Alt text](c6.png)

Check the version of maven by using this command 

**mvn -version**

**Command description:**
* **mvn:** It is the executable command for Apache Maven. It's used to interact with Maven from the command line. 

* **-version:** It is the argument or option that you can with the mvn command to retrive the information about it versions.

**Summary of the command:** The mvn -version command is used to display information about the installed Apache Maven version on your system.

![Alt text](c7.png)

## **4. Creating a Maven project**

Open terminal, goto the location where you want to get the project and use this command to get a maven project with cucumber dependencies.

~~~
mvn archetype:generate                      \
   "-DarchetypeGroupId=io.cucumber"           \
   "-DarchetypeArtifactId=cucumber-archetype" \
   "-DarchetypeVersion=7.12.1"               \
   "-DgroupId=search"                  \
   "-DartifactId=search"               \
   "-Dpackage=Search"                  \
   "-Dversion=1.0.0-SNAPSHOT"                 \
   "-DinteractiveMode=false"
~~~

#### **Options used and their significance**

* **-DarchetypeGroupId:** This option is used to specify the archetype group ID. We are using the cucumber archetype so we used the io.cucumber option.
  
* **-DarchetypeArtifactId:** This option is used to specify the archetype artifact ID. We are using the cucumber archetype so we used the cucumber-archetype.

* **-DarchetypeVersion:** This option is used to specify the version of the archetype. In this case, we are using the 7.12.1 version of archetype.
* **-DgroupId:** This option is used to specify the project's group ID. 
* **-DartifactId:** This option is used to specify the project's artifact ID. 

* **-Dpackage:** This option is used to specify the package name for the project's source code. Here, it is set to Search, indicating that the generated code will be placed in the Search package.

* **-Dversion:** This option is used to specify the project's version.
  
* **-DinteractiveMode:** This option is used to specify whether to run the archetype generation in interactive mode or not. false, meaning that the generation process will be non-interactive. If you set it to true, Maven will prompt you for additional information during the project generation process.

![Alt text](c8.png)

It will generate all the java files also like StepDefinition.java (inside search/src/test/java/Search) and an Example.feature (inside search/src/test/resources/Search) file. You have to delete the content of them and write/generate your own.

## **5. Pom.xml and its options with functions**

#### **Dependency Section**

The  **< dependencies >** section in the **pom.xml** file is used to declare the dependencies required for your project. Dependencies are external libraries or modules that your project relies on. Maven resolves and manages these dependencies automatically. The main function of this section is that when a project moves from one environment to another then there may be a mismatch of versions of installed software and there will be a chance of error due to mismatch so dependencies section will download them and the project will run smoothly without error due to mismatch. Here's an example:

~~~
<dependency>
<groupId>io.cucumber</groupId>
<artifactId>cucumber-java</artifactId>
<scope>test</scope>
</dependency>
~~~

In the example above, the **cucumber-java** artifact from the **io.cucumber** group with scope **test** is declared as a dependency for the project.

#### **Some other scopes**

Below are some other scope options:

* **compile:** This scope is used when dependencies are required at the time of compiling, building and running the main source code of the project. It is the default scope if we do not specify any other scope to the dependency. These dependencies are available in all classpaths and also during runtime.

* **provided:** Dependencies with the provided scope are required for compiling and building the project, but they are expected to be provided by the runtime environment or container where the project will be deployed. These dependencies are not included in the final packaged artifact as they are assumed to be available in the target environment.

* **runtime:** Dependencies with the runtime scope are required for running the project but are not needed during the compilation and build phases. They are made available during runtime and testing. These dependencies are not included in the final packaged artifact.

* **test:** Dependencies with the test scope are only used for the testing phase of the project. They are not transitive and are not included in the final packaged artifact.

* **system:** Dependencies with the system scope are similar to provided dependencies but require an explicit path to be specified using the **< systemPath >** element. These dependencies are not retrieved from a repository but are instead referenced directly from the local file system or another specified location.

* **import:** The import scope is used only in Maven's **< dependencyManagement >** section to import dependencies specified in another Maven project. This scope is not used directly in regular dependencies. Available for Maven 2.0.9 and later. 


#### **Build Section**

The **< build >** section contains instructions for building the project. It includes configurations for the build process, such as source directories, output directories, plugins, and more. Here's an example:

~~~
<build>
  <sourceDirectory>src/main/java</sourceDirectory>file:/home/tajfatima/search/src/test/java/
  <outputDirectory>target/classes</outputDirectory>
  <plugins>
    <!-- Plugin configurations -->
  </plugins>
</build>
~~~

In the above example, the **source directory** for Java code is set to **src/main/java,** and the output directory for compiled classes is set to **target/classes.** It also allows the inclusion of plugins for customising the build process.

**Note: It is not mandatory to provide the source and output directories in the build section. By default it will take src/main/java as source directory and target/classes as output directory.**

#### **Plugin Section**

The **< plugins >** section within the **< build >** section is used to configure **Maven plugins.** Plugins extend Maven's functionality and enable tasks like compiling code, running tests, packaging, and more. Here's an example.

~~~
<plugin>
<groupId>org.apache.maven.plugins</groupId>
<artifactId>maven-compiler-plugin</artifactId>
<version>3.11.0</version>
<configuration>
<encoding>UTF-8</encoding>
<source>17</source>
<target>17</target>
</configuration>
</plugin>
~~~

In the example, the **maven-compiler-plugin** is configured with **version 3.11.1**, and additional plugin-specific configurations can be added within the **< configuration >** element.

#### **Profile Section**

The **< profiles >** section allows the definition of different build configurations for specific environments or scenarios. Each profile can have its own set of dependencies, plugins, and configurations. Here's an example:

~~~
<profiles>
  <profile>
    <id>dev</id>
    <dependencies>
      <!-- Dependencies specific to the 'dev' profile -->
    </dependencies>
  </profile>
  <profile>
    <id>prod</id>
    <dependencies>
      <!-- Dependencies specific to the ‘prod’ profile -->
    </dependencies>
   </profile>
</profiles>
~~~

In the example, profiles named 'dev' and ‘prod’ are defined, and specific dependencies for both the environments can be added within the <dependencies> section.


**Search.feature file**

Now create a file under src/test/resources/Search **Search.feature.**  And start writing your feature file:

~~~
Feature: Search (Let only two types of product available for now)

 Scenario Outline: Search for desired product
   Given There is a search box
   When I type <arg>
   And click on search button
   Then <Results> should be displayed
   Examples:
     | arg                           | Results
     | Cricket bat of Kashmir Willow | Here are the results for what you have searched for
     | Football                      | Here are available footballs
     | Anything else!                | Sorry this product is not available right now
~~~

## **6. Adding step definitions automatically (auto generation of packages, classes and methods)**
Now you will see that all the steps (Given, When, Then) are highlighted in yellow. It means there are no step definitions provided for them, to add definitions, click on any step line and there a bulb like icon will appear. Click on that and choose **“Create all step definitions".**

![Alt text](c9.png)

Then a dialog box will appear asking the name of class and language and location where class to be generated. Enter all things correctly and hit ok.

![Alt text](c10.png)

#### **StepDefinitions.java**

It will generate the following StepDefinitions.java file under src/test/java/Search as I have entered to be created here.

~~~
package Search;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions {
   @Given("There is a search box")
   public void thereIsASearchBox() {
   }

   @When("I type {}")
   public void iType(String arg0) {
   }

   @And("click on search button")
   public void clickOnSearchButton() {
   }

   @Then("{} should be displayed")
   public void shouldBeDisplayed(String arg0) {
   }
}

~~~

## **7. Testing**

Now test this using the maven run feature. Here are the step : 

* Right click on the **RunCucumberTest.java** file and select **Run maven** then select **Test RunCucumberTest** and click on it.

![Alt text](c11.png)

* Or if we want to test from terminal first we have to **goto the project directory** then use this command to test **mvn test.(Which command)**

**Command description:**

* **mvn:** It is the executable command for Apache Maven. It's used to interact with Maven from the command line.


* **test:** Test phase is one of these predefined phases and is responsible for executing unit tests that are part of the project.

**Summary of the command:** It compiles the project's source code, runs unit tests using a testing framework like JUnit or Cucumber, and provides feedback on the test results, helping developers identify and address issues in their code.

![Alt text](c12.png)

Now you are able to see a success result on console.

![Alt text](c13.png)

![Alt text](c14.png)

This shows our tests are passed.

#### **Some other Maven options with functioning**

* **mvn clean:** This command cleans the project by deleting the target directory, which contains the compiled classes, generated files, and other build artifacts. It ensures a clean build environment before compiling and packaging the project.

![Alt text](c15.png)

* **mvn compile:** This command compiles the source code of the project. It takes the source files (.java files) from the src/main/java directory and compiles them into bytecode (.class files), placing the compiled classes in the target/test-classes/Search directory.

![Alt text](c16.png)

* **mvn package:** This command packages the compiled code and resources into a distributable format, such as a JAR (Java Archive) or a WAR (Web Application Archive). It creates the package in the target/test-classes directory.

![Alt text](c17.png)

* **mvn install:** This command will install the packaged artifact into the local Maven repository (on the local machine). It makes the artifact available for other projects or modules to use as a dependency.

To run a specific test instead of executing all the tests in our project, we can use the **-Dtest** option followed by the fully qualified name of the test class:

~~~
mvn test -Dtest= src/test/java/Search/StepDefinitions.java
~~~

In the above command, **src/test/java/Search/StepDefinitions.java** is the fully qualified name of the specific test class you want to run. Maven will execute only the tests within that class.

## **8. Define Maven repositories**

A Maven repository is a directory or a collection of directories that contain **Maven artifacts**. These artifacts are typically packaged as **JAR (Java Archive)** files but can also include other types of files, such as **WAR (Web Application Archive), POM (Project Object Model)**, and more.

Maven repositories serve as centralised locations for hosting and distributing software libraries, frameworks, and other components that are used as dependencies in Maven-based projects. The repositories allow developers to easily manage and retrieve these dependencies **without manually downloading** and configuring each one.

There are two main types of Maven repositories:

#### **Local Repository**

The local repository is a directory on **your local machine** where Maven stores downloaded artifacts and project-specific dependencies. When Maven resolves dependencies for a project, it first checks the local repository to see if the required artifacts are already present. If not found locally, Maven downloads the artifacts from remote repositories and caches them in the local repository for future use. The default location of the local repository is **~/.m2/repository on Unix-based systems and C:\Users\{username}\.m2\repository** on **Windows**.

Linux based os screenshot is below:

![Alt text](c18.png)

#### **Remote Repository**

Remote repositories are remote servers or services that host Maven artifacts. These repositories are defined in the pom.xml file or in the Maven settings.xml file. Maven retrieves artifacts from remote repositories when they are not available in the local repository. The **most commonly used** remote repository is the **Maven Central Repository,** which is a public repository hosting a large collection of open-source Java artifacts. There are also other remote repositories, such as those hosted by **organisations, companies, or individuals,** which can be added to the project's configuration as needed.

#### **Deliberately make the tests fail**

In order to make our tests fail we can use assertions.
Now we need to replace the StepDefinitions.java content with below content.

~~~
package Search;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;

public class StepDefinitions {
   private String actual;
   private String expected;

   @Given("There is a search box")
   public void thereIsASearchBox() {
   }

   @When("I type {}")
   public void iType(String arg) {
       expected= arg;
       actual="hello";
   }

   @And("click on search button")
   public void clickOnSearchButton() {
   }

   @Then("{} should be displayed")
   public void shouldBeDisplayed(String arg) {
       Assertions.assertEquals(expected,actual);
   }
}
~~~

Then again test and you will see this time scenarios getting failed.

![Alt text](c19.png)



**Through terminal**

![Alt text](c20.png)

![Alt text](c21.png)

![Alt text](c22.png)


## **Reference link:**

*  http://github.com/kylecoberly/knowledge/wiki/gherkin
*  https://www.youtube.com/watch?v=bS9Q0_uKAs8
*  https://medium.com/@JoeTann/front-end-tutorial-on-behavior-driven-development-with-cucumber-cypress-and-jest-a7e28c517e1
*  https://www.tutorialspoint.com/how-to-skip-a-particular-test-method-from-execution-in-cucumber
*  https://qaautomation.expert/2021/03/26/run-cucumber-test-from-command-line/
*  https://github.com/kylecoberly/knowledge/wiki/Cypress-Cucumber


