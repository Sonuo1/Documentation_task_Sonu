# Setup of MetalLB


## Table of Contents 

* Requirement of MetalLB 
  * Env Detail (OS Version) :
  * List of tools and technologies:

* What is Kubernetes ?
* What is MetalLB ?
* Install Kubernetes
* Install Minikube
* Install kubectl
* Start Minikube
* Installation of MetalLB by manifest


##  **Requirement of MetalLB**

In the bare metal deployment kubernetes does not provide the functionality of creating Load Balancer on service by default

### Env detail (OS Version ) :

  * Distributor ID : Ubuntu
  * Description : Ubuntu 22.04.3 LTS
  * Release : 20.04
  * Codename : jammy

### List of tools and technologies:

  * Kubernetes
  * MetalLB
  * Docker

## What is Kubernetes ?

Think of Kubernetes as a smart manager for your applications. Imagine you have lots of little workers (containers) who need to run your programs. Kubernetes is like a boss who organises and manages these workers efficiently. It makes sure your programs are running, scales them when needed, and even replaces them if they fail.


## 3 . What is MetalLB ?</b></h2></br>
Picture MetalLB as a friendly valet for your apps in Kubernetes. Normally, LoadBalancers help direct internet traffic to different services, like websites or apps. MetalLB does this even if you're not on a big cloud service (like Amazon or Google). It helps your Kubernetes apps get the right traffic and lets them talk to the world.
<h2><b>4 . Install Kubernetes</b></h2></br>
Here's a general outline of the steps you would follow to install Kubernetes on Ubuntu:</br>
<b>Step 1 :</b> Update and Upgrade :</br>

<b>Command:</b> sudo apt-get update</br>
<b>Command:</b> sudo apt-get upgrade</br>
<b>Step 2 :</b> Install Docker : Kubernetes relies on Docker for containerization. Install Docker using the following commands:</br>

<b>Command:</b> sudo apt-get install docker.io</br>
<b>Command:</b> sudo systemctl enable docker</br>
<b>Command:</b> sudo systemctl start docker</br>
<b>Step 3 : Install kubeadm, kubelet, and kubectl : </b> These are the essential components of Kubernetes.</br>

<b>Command:</b>  sudo apt-get install -y apt-transport-https curl</br>
curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -</br>
curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -</br>
curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -</br>
echo "deb https://apt.kubernetes.io/ kubernetes-xenial main" | sudo tee /etc/apt/sources.list.d/kubernetes.list</br>

<b>Command:</b> sudo apt-get update</br>
<b>Command:</b> sudo apt-get install -y kubelet kubeadm kubectl</br>
<b>Step 4 : Initialize Kubernetes Master Node (Control Plane) :</b> On the master node, you'll initialize Kubernetes using kubeadm. Run the following command to initialize the master node:
  
<b>Command:</b> sudo kubeadm init</br>
<b>Error:</b></br>


![Alt text](err.png)

<br>According to the document I have faced the issue.</br>
<br><b>PROBLEM 1:</b> </br>

So, I have followed these steps to install the Minikube cluster on my system Ubuntu 20.04:  for setup of metalLB.</br>

 <h1><b>Installation of Minikube Cluster</b></h1>

<b>Step 1:</b> Installing Minikube 

  wgethttps://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64

![Alt text](Mini1.png)

<b>Step 2:</b> Then copy the downloaded binary to the system path using the following </br>
<b>command:</b> cp minikube-linux-amd64 /usr/local/bin/minikube

<br><<b>Step 3:</b> Provide the execution permission</br>
<b>Command:</b> chmod 755 /usr/local/bin/minikube


<br><b>Step 4:</b> Then check the minikube version.</br>
<b>Command :</b> minikube version

![Alt text](m2.png)

<h3><b>Install kubectl</b></h3></br>

<b>Step 5:</b>  Install Kubectl and other tools to manage applications on Kubernetes. First, add the GPG key with the following command:

<b>Command:</b> curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add

<br><b>Step 6:</b> Then add the kubectl repository</br>
<b>Command:</b> echo "deb http://apt.kubernetes.io/ kubernetes-xenial main" | tee /etc/apt/sources.list.d/kubernetes.list

![Alt text](m3.png)

<b>Step 7:</b> install the Kubectl

<b>Command:</b> apt-get update -y
apt-get install kubectl kubeadm kubectl -y

![Alt text](m4.png)


<h3><b>Start Minikube</b></h3></br>

<b>Step 8:</b> Then we start the Minikube.</br>
<b>Command:</b> minikube start --force

![Alt text](m5.png)

<br><b>Step 9:</b> Then check the cluster information</br>
<b>Command:</b> kubectl cluster-info

<b>Step 10:</b> Then check the Kubectl default configuration

![Alt text](m6.png)

<br><b>Step 11:</b> Then check all the running nodes </br>
<b>Command:</b> kubectl get nodes

<b>Step 12:</b> Then verify the status of Minikube

<b>Command:</b> minikube status

![Alt text](m7.png)

<b>Step 13:</b> Then list all addons in minikube.</br>
<b>Command:</b> minikube addons list</br>

![Alt text](m8.png)

<b>Step 14:</b> Then list all the container image running in the cluster </br>
<b>Command:</b> kubectl get pods --all-namespaces</br>

![Alt text](m9.png)

<b>Step 15:</b> Enable the Kubernetes dashboard and get the URL</br>
<b>Command:</b> minikube dashboard --url </br>

![Alt text](m10.png)

<b>Step 16:</b> On the browser we have passed the url then it opens the dashboard.</br>
<b>Output:</b> </br>

![Alt text](m11.png)


<h2><b>Installation of the MetalLB</b></h2></br>


<b>PROBLEM 2:</b> Installation of the Metal Lb link is not correct. So I have followed these documents to resolve this issue.

<b>Link:</b> https://metallb.universe.tf/installation/

<b>Step 1:</b> To install MetalLB, apply the manifest:

<b>Command: </b>kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/v0.13.10/config/manifests/metallb-native.yaml

<b>Command:</b>  kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/v0.13.10/config/manifests/metallb-frr.yaml

<b>PROBLEM 3:</b> When I am going to expose the service then it shows the <External IP> pending state.</br>

<b>Command:</b> kubectl get svc nginx-service </br>


So, then I have removed all configuration files and add these steps according to the document to resolve this issue which is listed below:</br>
<b>Document Link:</b> https://kubebyexample.com/learning-paths/metallb/install
****
Installation steps is the same but the I have add these steps in this document which is listed below:</br>


<b>Step 1:</b> List the driver on which the minikube VM is created.</br>
<b>Command:</b> minikube profile list</br>

![Alt text](s1.png)

<b>Step 2:</b> Verify that metallb is listed on the available add-ons for minikube.</br>
<b>Command:</b> Minikube addons list

![Alt text](s2.png)

<b>Step 3</b>:Enable the MetalLB minikube add-on.</br>
<b>Command:</b> minikube addons enable metallb

![Alt text](s3.png)

<b>Step 4:</b> Configure the IP addresses that can be used by MetalLB for the LoadBalancer services.</br>
<b>Command:</b> minikube addons configure metallb

![Alt text](s4.png)

<b>Step 5:</b> Review the applied settings.</br>
<b>Command:</b> kubectl get configmap/config -n metallb-system -o yaml

![Alt text](s5.png)

<b>Step 6:</b> Create a deployment with a sample application.</br>
<b>Command:</b>  kubectl create deployment nginx \
>   --image quay.io/redhattraining/nginx:1.21 --port 80

![Alt text](s6.png)
<b>Step 7:</b> Verify that the deployment and pod are ready.</br>
<b>Command:</b> kubectl get deployments,pods -l app=nginx

![Alt text](s7.png)
<b>Step 8:</b> Expose the deployment to create a load balancer service.</br>
<b>Command: </b>
![Alt text](s8.png)
<b>Step 9:</b> Get the external IP address for the load balancer service.</br>
<b>Command:</b> kubectl get services -l app=nginx
![Alt text](s9.png)
<b>I have added this query in this document to verfication of the load balancer service using curl and the browser.</br>
<b>Step 10:</b> Verify that the service responds with curl</br>
<b>Command:</b> curl http://192.168.59.22
![Alt text](s10.png)
<b>Step 11: </b> Verify that the service responds with browser.</br>
<b>Command:</b>  http://192.168.59.22

![Alt text](s11.png)